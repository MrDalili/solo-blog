title: CL配置出了VS以外的编译器
date: '2019-09-27 20:35:59'
updated: '2019-09-27 20:59:03'
tags: [c++, 教程]
permalink: /articles/2019/09/27/1569587759805.html
---
上一篇博客写了如何在CL中配置VS的编译环境。第二天手撕链表的时候，出了些小bug，想debug一下，发现cl不支持vs编译器的debug。。好吧，那我要你干嘛。
![把VS丢了][1]
接下来说一下，示范一下在cl中配置MinGW
## 配置流程
你可以在CL的配置中点击下载按钮下载
![点击下载][2]
进入网页后观察是否为W64的页面，如果是点击下方的**sourceforge**按钮，如果不是点击右上角的Downloads，寻找**MingW-W64-builds**点击下载。或者[点击这里下载](https://nchc.dl.sourceforge.net/project/mingw-w64/Toolchains%20targetting%20Win32/Personal%20Builds/mingw-builds/installer/mingw-w64-install.exe)Windows的WinGW。
![下载WinGW][3]
下载好后，安装我就不一步一步教大家做了，接下来就需要在CL中配置WinGW的编译器啦。
![选择相应的目录][4]
接下来就可以使用Debug功能了，我觉得很ok哈哈哈哈。
**如果你想使用别的编译器，那你们换成相应的下拉框选项就好了，按照步骤走一遍啦。**
下次见奥~
![完结撒花][5]





[1]:https://qiniuyun.ningdali.com/solo/190927_cl/要你干嘛.png
[2]:https://qiniuyun.ningdali.com/solo/190927_cl/1.png
[3]:https://qiniuyun.ningdali.com/solo/190927_cl/2.png
[4]:https://qiniuyun.ningdali.com/solo/190927_cl/3.png
[5]:https://qiniuyun.ningdali.com/solo/190927_cl/完结撒花.jpg
