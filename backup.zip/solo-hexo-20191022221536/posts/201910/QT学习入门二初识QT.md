title: QT学习入门（二）——初识QT
date: '2019-10-01 09:56:44'
updated: '2019-10-01 09:56:44'
tags: [c++, QT]
permalink: /articles/2019/10/01/1569895003994.html
---
## 按钮的学习
+ **创建**
```qt
//创建一个按钮,这样就是创建一个没有属性的button需要自己添加
  QPushButton  *  btn  =  new  QPushButton;
//创建一个按钮，绑定在父窗口中并设置名字
  QPushButton  *  btn2  =  new  QPushButton("第二个按钮",this);
```
+ 绑定到某个窗口
```qt
//让btn对象依赖当前窗口,this表示当前窗口
btn->setParent(this);
```

+ 给button设置文本
```qt
//设置文本
btn->setText("第一个按钮");
```

+ 移动button位置
```qt
//移动被btn2的位置
btn2->move(0,100);
```

## 窗口学习
+ 重置窗口大小
```qt
//重置大小
resize(600,400);
```
+ 设置固定的窗口大小
```qt
 //设置固定的窗口大小  
 setFixedSize(600,400);
```
 + 设置窗口标题
```qt
//设置窗口标题
setWindowTitle("第一个窗口");
```
