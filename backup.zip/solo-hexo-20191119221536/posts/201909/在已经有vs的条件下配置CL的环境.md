title: 在已经有vs的条件下配置CL的环境
date: '2019-09-24 22:53:59'
updated: '2019-09-25 06:56:27'
tags: [c++, 教程]
permalink: /articles/2019/09/24/1569336839527.html
---
## 前言
JB公司的软件用的都很nice，反观vs，虽然说是宇宙第一IDE但是在我心里，打代码的智能提醒并不入JB公司做的好，所以我在平时不用到MFC这些的时候还是会用CL去写c的代码。
刚好要带着工作室的小伙伴一起手撕链表，就先配置一下CL的编译环境。
## 第一步 准备一下软件
你得先有个宇宙第一IDE和CL这俩个牛皮的软件。hhhh
![这俩个用红色圈起来的软件][1]
## 第二步 配置环境
VS,CL我没有破解，如果你要破解，你百度一下就好了。
1. 进入CL的Setting
![点击这个setting][2]
2. 在左上角**搜索**Toolchains
![搜索][3]
3. 在右边的**Environment**中选择**Visual Studio**
![点击][4]
4. 在右边的扩展中选择你电脑中对应的Visual Studio的目录.如果你不知道的话，你可以把你在那幢Visual Studio时的对应的3个文件都选择一下。出现对应Version的时候说明配置好了。
![选择对应的路径][5]
5. 你可以继续配置你想每一次编译的环境，因为我是amd的cpu所以对应的时amd64这个看你的需要，一般32位用来手撕代码就够了。
![选择你想要的编译环境][6]
## 完成
这时候就已经差不多完成了，你可以创建一个hello world的project来测试一下，在下方的terminal中输出hello world就算配置成功啦~
![最终测试][7]

[1]:https://qiniuyun.ningdali.com/solo/190924_cl/1.png
[2]:https://qiniuyun.ningdali.com/solo/190924_cl/2.png
[3]:https://qiniuyun.ningdali.com/solo/190924_cl/3.png
[4]:https://qiniuyun.ningdali.com/solo/190924_cl/4.png
[5]:https://qiniuyun.ningdali.com/solo/190924_cl/5.png
[6]:https://qiniuyun.ningdali.com/solo/190924_cl/6.png
[7]:https://qiniuyun.ningdali.com/solo/190924_cl/7.png

